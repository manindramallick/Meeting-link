package com.kafka.config;

import com.kafka.properties.KafkaProducerProperties;
import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.config.SaslConfigs;
import org.apache.kafka.common.config.SslConfigs;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.kafka.support.serializer.JsonSerializer;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;

import java.util.HashMap;
import java.util.Map;


@Configuration
@EnableConfigurationProperties(KafkaProducerProperties.class)
public class KafkaProducerConfig {

    private final KafkaProducerProperties props;

    public KafkaProducerConfig(KafkaProducerProperties props) {
        this.props = props;
    }


    /**
     * Creates a ProducerFactory bean that is responsible for creating Kafka producer instances.
     * The producer factory is configured with the producer configurations defined in the producerConfigs() method.
     * @return A ProducerFactory instance for creating Kafka producers.
     */

    @Bean
    public ProducerFactory<String, Object> kafkaProducerFactory() {
        return new DefaultKafkaProducerFactory<>(producerConfigs());
    }

    /**
     * Creates a KafkaTemplate bean that can be injected into other components for publishing messages to Kafka.
     * The KafkaTemplate is configured with the producer factory that uses the specified producer configurations.
     * @return A KafkaTemplate instance for sending messages to Kafka topics.
     */

    @Bean
    public KafkaTemplate<String, Object> kafkaTemplate() {
        return new KafkaTemplate<>(kafkaProducerFactory());
    }


    /**
     * Builds the configuration map for the Kafka producer, including bootstrap servers, serializers, security settings, and any additional properties specified in the configuration.
     * @return A map of configuration properties for the Kafka producer.
     */

    Map<String, Object> producerConfigs() {
        Map<String, Object> config = new HashMap<>();
        config.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, props.getBootstrapServers());
        config.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        config.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);
        config.put(JsonSerializer.ADD_TYPE_INFO_HEADERS, false);
        config.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, "SASL_SSL");
        config.put(SaslConfigs.SASL_MECHANISM, "PLAIN");
        config.put(SaslConfigs.SASL_JAAS_CONFIG,
                "org.apache.kafka.common.security.plain.PlainLoginModule required "
                        + "username=\"" + props.getApiKey() + "\" "
                        + "password=\"" + props.getApiSecret() + "\";");
        config.put(SslConfigs.SSL_ENDPOINT_IDENTIFICATION_ALGORITHM_CONFIG, "https");

        config.put(ProducerConfig.ACKS_CONFIG, props.getAcks());
        config.put(ProducerConfig.RETRIES_CONFIG, props.getRetries());
        config.put(ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG, true);
        config.put(ProducerConfig.LINGER_MS_CONFIG, 5);
        config.put(ProducerConfig.BATCH_SIZE_CONFIG, 16384);
        config.put(ProducerConfig.COMPRESSION_TYPE_CONFIG, "lz4");
        if (props.getAdditionalProperties() != null) {
            config.putAll(props.getAdditionalProperties());
        }

        return config;
    }
}

