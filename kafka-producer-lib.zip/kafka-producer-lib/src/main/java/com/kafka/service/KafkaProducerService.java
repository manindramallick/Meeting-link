package com.kafka.service;

import com.kafka.exception.KafkaPublishException;
import com.kafka.model.PublishResult;
import com.kafka.model.RequestPayload;
import com.kafka.properties.KafkaProducerProperties;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.concurrent.CompletableFuture;

/**
 * Service class responsible for publishing messages to Kafka topics.
 * Provides methods for synchronous, asynchronous, and batch publishing of messages.
 * Handles topic resolution based on the payload and configuration properties.
 */
@Slf4j
@Service
public class KafkaProducerService {

    private final KafkaTemplate<String, Object> kafkaTemplate;
    private final KafkaProducerProperties props;

    public KafkaProducerService(KafkaTemplate<String, Object> kafkaTemplate,
                                KafkaProducerProperties props) {
        this.kafkaTemplate = kafkaTemplate;
        this.props = props;
    }


    /**
     * Publishes a message to Kafka using the topic specified in the payload or the default topic from properties.
     * This method is fire-and-forget and does not wait for the publish result.
     * @param payload The message payload containing the topic, key, and value to be published.
     */

    public void publish(RequestPayload payload) {
        String topic = resolveTopic(payload);
        log.info("Publishing message to topic='{}' key='{}'", topic, payload.getKey());

        kafkaTemplate.send(topic, payload.getKey(), payload)
                .whenComplete((result, ex) -> {
                    if (ex != null) {
                        log.error("Failed to publish to topic='{}': {}", topic, ex.getMessage(), ex);
                    } else {
                        log.info("Published to topic='{}' partition={} offset={}",
                                topic,
                                result.getRecordMetadata().partition(),
                                result.getRecordMetadata().offset());
                    }
                });
    }


    /**
     * Publishes a message to Kafka and waits for the result, returning a PublishResult object with details of the operation.
     * @param payload The message payload containing the topic, key, and value to be published.
     * @return A PublishResult object containing the outcome of the publish operation.
     * @throws KafkaPublishException if the publish operation fails or is interrupted.
     */
    public PublishResult publishSync(RequestPayload payload) {
        String topic = resolveTopic(payload);
        log.info("Publishing (sync) to topic='{}' key='{}'", topic, payload.getKey());
        try {
            SendResult<String, Object> result =
                    kafkaTemplate.send(topic, payload.getKey(), payload).get();

            int partition = result.getRecordMetadata().partition();
            long offset    = result.getRecordMetadata().offset();
            log.info("Sync publish OK – topic='{}' partition={} offset={}", topic, partition, offset);
            return PublishResult.ok(topic, partition, offset);

        } catch (InterruptedException ie) {
            Thread.currentThread().interrupt();
            throw new KafkaPublishException(topic, "Publish interrupted", ie);
        } catch (Exception e) {
            log.error("Sync publish failed for topic='{}': {}", topic, e.getMessage(), e);
            throw new KafkaPublishException(topic, e.getMessage(), e);
        }
    }

  /**
     * Publishes a message to Kafka asynchronously, returning a CompletableFuture that will complete with the PublishResult.
     * @param payload The message payload containing the topic, key, and value to be published.
     * @return A CompletableFuture that will complete with a PublishResult object containing the outcome of the publish operation.
     */
    public CompletableFuture<PublishResult> publishAsync(RequestPayload payload) {
        String topic = resolveTopic(payload);
        log.info("Publishing (async) to topic='{}' key='{}'", topic, payload.getKey());

        return kafkaTemplate.send(topic, payload.getKey(), payload)
                .thenApply(result -> PublishResult.ok(
                        topic,
                        result.getRecordMetadata().partition(),
                        result.getRecordMetadata().offset()))
                .exceptionally(ex -> {
                    log.error("Async publish failed for topic='{}': {}", topic, ex.getMessage(), ex);
                    return PublishResult.fail(topic, ex.getMessage());
                });
    }

   /**
     * Publishes a batch of messages to Kafka. Each message in the batch will be published using the publish method.
     * If the payload list is null or empty, the method will log a warning and return without publishing.
     *
     * @param payloads A list of RequestPayload objects to be published to Kafka.
     */
    public void publishBatch(List<RequestPayload> payloads) {
        if (payloads == null || payloads.isEmpty()) {
            log.warn("publishBatch called with empty or null payload list – skipping");
            return;
        }
        log.info("Batch publishing {} message(s)", payloads.size());
        payloads.forEach(this::publish);
    }


   /**
    * Resolves the Kafka topic to publish to based on the RequestPayload and configuration properties.
     * If the payload specifies a topic, it will be used. Otherwise, the default topic from properties will be used.
     * If no topic can be resolved, a KafkaPublishException will be thrown.
     *
     * @param payload The RequestPayload containing the potential topic information.
     * @return The resolved Kafka topic to publish to.
     * @throws KafkaPublishException if no valid topic can be resolved from the payload or properties.
     */
    private String resolveTopic(RequestPayload payload) {
        if (payload == null) {
            throw new KafkaPublishException(props.getMainTopic(),
                    "RequestPayload must not be null");
        }
        String topic = (payload.getTopic() != null && !payload.getTopic().isBlank())
                ? payload.getTopic()
                : props.getMainTopic();

        if (topic == null || topic.isBlank()) {
            throw new KafkaPublishException("UNKNOWN",
                    "No topic specified in payload and kafka.producer.default-topic is not set");
        }
        return topic;
    }
}

