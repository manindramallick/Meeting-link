package com.kafka.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

/**
 * Immutable payload representing the data to be published to Kafka.
 * This is the object that will be serialized to JSON and sent as the message value.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RequestPayload {

    private String topic;
    private String key;
    private String payload;
    @Builder.Default
    private Instant createdAt = Instant.now();
}

