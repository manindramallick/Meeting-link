package com.kafka.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

/**
 * Immutable result object representing the outcome of a publish operation.
 * Contains details about the success or failure of the publish attempt, including topic, partition, offset, and any error messages.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PublishResult {

    private boolean success;
    private String topic;
    @Builder.Default
    private int partition = -1;
    @Builder.Default
    private long offset = -1L;
    @Builder.Default
    private Instant publishedAt = Instant.now();

    private String errorMessage;

    public static PublishResult ok(String topic, int partition, long offset) {
        return PublishResult.builder()
                .success(true)
                .topic(topic)
                .partition(partition)
                .offset(offset)
                .build();
    }

    public static PublishResult fail(String topic, String errorMessage) {
        return PublishResult.builder()
                .success(false)
                .topic(topic)
                .errorMessage(errorMessage)
                .build();
    }
}

