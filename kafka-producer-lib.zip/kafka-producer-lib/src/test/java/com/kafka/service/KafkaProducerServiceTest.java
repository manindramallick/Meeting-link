package com.kafka.service;

import com.kafka.exception.KafkaPublishException;
import com.kafka.model.PublishResult;
import com.kafka.model.RequestPayload;
import com.kafka.properties.KafkaProducerProperties;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.TopicPartition;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("KafkaProducerService Tests")
class KafkaProducerServiceTest {

    @Mock
    private KafkaTemplate<String, Object> kafkaTemplate;

    private KafkaProducerProperties props;
    private KafkaProducerService service;

    @BeforeEach
    void setUp() {
        props = new KafkaProducerProperties();
        props.setMainTopic("default-topic");
        service = new KafkaProducerService(kafkaTemplate, props);
    }


    @Nested
    @DisplayName("publish() - fire-and-forget")
    class PublishTests {

        @Test
        @DisplayName("should send message to the topic specified in payload")
        void publish_sendsToPayloadTopic() {
            RequestPayload payload = buildPayload("orders-topic", "order-1", "order data");
            when(kafkaTemplate.send(eq("orders-topic"), eq("order-1"), any()))
                    .thenReturn(completedFuture("orders-topic", 0, 1L));

            service.publish(payload);

            verify(kafkaTemplate).send(eq("orders-topic"), eq("order-1"), any());
        }

        @Test
        @DisplayName("should fall back to mainTopic when payload topic is null")
        void publish_usesDefaultTopicWhenPayloadTopicIsNull() {
            RequestPayload payload = RequestPayload.builder()
                    .key("k1")
                    .payload("some data")
                    .build(); // topic = null

            when(kafkaTemplate.send(eq("default-topic"), eq("k1"), any()))
                    .thenReturn(completedFuture("default-topic", 0, 2L));

            service.publish(payload);

            verify(kafkaTemplate).send(eq("default-topic"), eq("k1"), any());
        }

        @Test
        @DisplayName("should fall back to mainTopic when payload topic is blank")
        void publish_usesDefaultTopicWhenPayloadTopicIsBlank() {
            RequestPayload payload = buildPayload("  ", "k2", "data");

            when(kafkaTemplate.send(eq("default-topic"), eq("k2"), any()))
                    .thenReturn(completedFuture("default-topic", 0, 3L));

            service.publish(payload);

            verify(kafkaTemplate).send(eq("default-topic"), eq("k2"), any());
        }

        @Test
        @DisplayName("should log error on broker failure without throwing")
        void publish_logsErrorOnBrokerFailure() {
            RequestPayload payload = buildPayload("orders-topic", "k3", "data");
            CompletableFuture<SendResult<String, Object>> failed = new CompletableFuture<>();
            failed.completeExceptionally(new RuntimeException("broker down"));
            when(kafkaTemplate.send(eq("orders-topic"), eq("k3"), any())).thenReturn(failed);


            service.publish(payload);

            verify(kafkaTemplate).send(eq("orders-topic"), eq("k3"), any());
        }

        @Test
        @DisplayName("should throw KafkaPublishException when payload is null")
        void publish_throwsWhenPayloadIsNull() {
            assertThatThrownBy(() -> service.publish(null))
                    .isInstanceOf(KafkaPublishException.class)
                    .hasMessageContaining("RequestPayload must not be null");
        }

        @Test
        @DisplayName("should throw KafkaPublishException when no topic in payload and no mainTopic set")
        void publish_throwsWhenNoTopicResolvable() {
            props.setMainTopic(null);
            RequestPayload payload = RequestPayload.builder().payload("data").build();

            assertThatThrownBy(() -> service.publish(payload))
                    .isInstanceOf(KafkaPublishException.class)
                    .hasMessageContaining("No topic specified");
        }
    }


    @Nested
    @DisplayName("publishSync() - blocking")
    class PublishSyncTests {

        @Test
        @DisplayName("should return successful PublishResult with correct partition and offset")
        void publishSync_returnsSuccessResult() {
            RequestPayload payload = buildPayload("sync-topic", "s1", "sync data");
            when(kafkaTemplate.send(eq("sync-topic"), eq("s1"), any()))
                    .thenReturn(completedFuture("sync-topic", 2, 99L));

            PublishResult result = service.publishSync(payload);

            assertThat(result.isSuccess()).isTrue();
            assertThat(result.getTopic()).isEqualTo("sync-topic");
            assertThat(result.getPartition()).isEqualTo(2);
            assertThat(result.getOffset()).isEqualTo(99L);
            assertThat(result.getErrorMessage()).isNull();
        }

        @Test
        @DisplayName("should use mainTopic as fallback when payload topic is null")
        void publishSync_fallsBackToMainTopic() {
            RequestPayload payload = RequestPayload.builder().key("s2").payload("data").build();
            when(kafkaTemplate.send(eq("default-topic"), eq("s2"), any()))
                    .thenReturn(completedFuture("default-topic", 1, 10L));

            PublishResult result = service.publishSync(payload);

            assertThat(result.isSuccess()).isTrue();
            assertThat(result.getTopic()).isEqualTo("default-topic");
        }

        @Test
        @DisplayName("should throw KafkaPublishException when broker returns error")
        void publishSync_throwsOnBrokerError() {
            RequestPayload payload = buildPayload("sync-topic", "s3", "data");
            CompletableFuture<SendResult<String, Object>> failed = new CompletableFuture<>();
            failed.completeExceptionally(new RuntimeException("timeout"));
            when(kafkaTemplate.send(eq("sync-topic"), eq("s3"), any())).thenReturn(failed);

            assertThatThrownBy(() -> service.publishSync(payload))
                    .isInstanceOf(KafkaPublishException.class)
                    .hasMessageContaining("timeout");
        }

        @Test
        @DisplayName("should rethrow InterruptedException wrapped in KafkaPublishException")
        void publishSync_throwsOnInterruption() throws Exception {
            RequestPayload payload = buildPayload("sync-topic", "s4", "data");

            @SuppressWarnings("unchecked")
            CompletableFuture<SendResult<String, Object>> mockFuture = mock(CompletableFuture.class);
            when(mockFuture.get()).thenThrow(new InterruptedException("interrupted"));
            when(kafkaTemplate.send(eq("sync-topic"), eq("s4"), any())).thenReturn(mockFuture);

            assertThatThrownBy(() -> service.publishSync(payload))
                    .isInstanceOf(KafkaPublishException.class)
                    .hasMessageContaining("interrupted");


            assertThat(Thread.currentThread().isInterrupted()).isTrue();
            Thread.interrupted();
        }

        @Test
        @DisplayName("should throw KafkaPublishException when payload is null")
        void publishSync_throwsWhenPayloadIsNull() {
            assertThatThrownBy(() -> service.publishSync(null))
                    .isInstanceOf(KafkaPublishException.class)
                    .hasMessageContaining("RequestPayload must not be null");
        }
    }

    @Nested
    @DisplayName("publishAsync() - non-blocking")
    class PublishAsyncTests {

        @Test
        @DisplayName("should return CompletableFuture with successful PublishResult")
        void publishAsync_returnsSuccessfulFuture() throws Exception {
            RequestPayload payload = buildPayload("async-topic", "a1", "async data");
            when(kafkaTemplate.send(eq("async-topic"), eq("a1"), any()))
                    .thenReturn(completedFuture("async-topic", 3, 77L));

            PublishResult result = service.publishAsync(payload).get();

            assertThat(result.isSuccess()).isTrue();
            assertThat(result.getTopic()).isEqualTo("async-topic");
            assertThat(result.getPartition()).isEqualTo(3);
            assertThat(result.getOffset()).isEqualTo(77L);
        }

        @Test
        @DisplayName("should return failed PublishResult (not throw) when broker errors")
        void publishAsync_returnsFailedResultOnBrokerError() throws Exception {
            RequestPayload payload = buildPayload("async-topic", "a2", "data");
            CompletableFuture<SendResult<String, Object>> failed = new CompletableFuture<>();
            failed.completeExceptionally(new RuntimeException("connection refused"));
            when(kafkaTemplate.send(eq("async-topic"), eq("a2"), any())).thenReturn(failed);

            PublishResult result = service.publishAsync(payload).get();

            assertThat(result.isSuccess()).isFalse();
            assertThat(result.getTopic()).isEqualTo("async-topic");
            assertThat(result.getErrorMessage()).contains("connection refused");
        }

        @Test
        @DisplayName("should complete future exceptionally when payload is null")
        void publishAsync_throwsWhenPayloadIsNull() {
            assertThatThrownBy(() -> service.publishAsync(null))
                    .isInstanceOf(KafkaPublishException.class);
        }
    }

    @Nested
    @DisplayName("publishBatch() - batch")
    class PublishBatchTests {

        @Test
        @DisplayName("should send all messages in the batch")
        void publishBatch_sendsAllMessages() {
            List<RequestPayload> batch = List.of(
                    buildPayload("batch-topic", "b1", "data1"),
                    buildPayload("batch-topic", "b2", "data2"),
                    buildPayload("batch-topic", "b3", "data3")
            );
            when(kafkaTemplate.send(eq("batch-topic"), anyString(), any()))
                    .thenReturn(completedFuture("batch-topic", 0, 1L));

            service.publishBatch(batch);

            verify(kafkaTemplate, times(3)).send(eq("batch-topic"), anyString(), any());
        }

        @Test
        @DisplayName("should capture correct keys for each message in batch")
        void publishBatch_sendsCorrectKeys() {
            List<RequestPayload> batch = List.of(
                    buildPayload("batch-topic", "key-A", "dataA"),
                    buildPayload("batch-topic", "key-B", "dataB")
            );
            when(kafkaTemplate.send(anyString(), anyString(), any()))
                    .thenReturn(completedFuture("batch-topic", 0, 1L));

            service.publishBatch(batch);

            ArgumentCaptor<String> keyCaptor = ArgumentCaptor.forClass(String.class);
            verify(kafkaTemplate, times(2)).send(anyString(), keyCaptor.capture(), any());
            assertThat(keyCaptor.getAllValues()).containsExactlyInAnyOrder("key-A", "key-B");
        }

        @Test
        @DisplayName("should skip publishing and not call kafkaTemplate when list is empty")
        void publishBatch_skipsWhenListIsEmpty() {
            service.publishBatch(List.of());

            verifyNoInteractions(kafkaTemplate);
        }

        @Test
        @DisplayName("should skip publishing and not call kafkaTemplate when list is null")
        void publishBatch_skipsWhenListIsNull() {
            service.publishBatch(null);

            verifyNoInteractions(kafkaTemplate);
        }

        @Test
        @DisplayName("should send single message batch")
        void publishBatch_sendsSingleMessage() {
            List<RequestPayload> batch = List.of(
                    buildPayload("single-topic", "s1", "only one")
            );
            when(kafkaTemplate.send(eq("single-topic"), eq("s1"), any()))
                    .thenReturn(completedFuture("single-topic", 0, 5L));

            service.publishBatch(batch);

            verify(kafkaTemplate, times(1)).send(eq("single-topic"), eq("s1"), any());
        }
    }


    @Nested
    @DisplayName("resolveTopic() - topic resolution")
    class ResolveTopicTests {

        @Test
        @DisplayName("should prefer payload topic over mainTopic")
        void resolveTopic_prefersPayloadTopic() {
            props.setMainTopic("fallback-topic");
            RequestPayload payload = buildPayload("explicit-topic", "k1", "data");
            when(kafkaTemplate.send(eq("explicit-topic"), eq("k1"), any()))
                    .thenReturn(completedFuture("explicit-topic", 0, 1L));

            PublishResult result = service.publishSync(payload);

            assertThat(result.getTopic()).isEqualTo("explicit-topic");
        }

        @Test
        @DisplayName("should use mainTopic when payload topic is null")
        void resolveTopic_usesMainTopicWhenNull() {
            RequestPayload payload = RequestPayload.builder().key("k2").payload("data").build();
            when(kafkaTemplate.send(eq("default-topic"), eq("k2"), any()))
                    .thenReturn(completedFuture("default-topic", 0, 1L));

            PublishResult result = service.publishSync(payload);

            assertThat(result.getTopic()).isEqualTo("default-topic");
        }

        @Test
        @DisplayName("should use mainTopic when payload topic is blank string")
        void resolveTopic_usesMainTopicWhenBlank() {
            RequestPayload payload = buildPayload("   ", "k3", "data");
            when(kafkaTemplate.send(eq("default-topic"), eq("k3"), any()))
                    .thenReturn(completedFuture("default-topic", 0, 1L));

            PublishResult result = service.publishSync(payload);

            assertThat(result.getTopic()).isEqualTo("default-topic");
        }

        @Test
        @DisplayName("should throw UNKNOWN KafkaPublishException when both topic and mainTopic are null")
        void resolveTopic_throwsWhenBothTopicsAreNull() {
            props.setMainTopic(null);
            RequestPayload payload = RequestPayload.builder().payload("data").build();

            assertThatThrownBy(() -> service.publishSync(payload))
                    .isInstanceOf(KafkaPublishException.class)
                    .hasMessageContaining("No topic specified");
        }

        @Test
        @DisplayName("should throw UNKNOWN KafkaPublishException when both topic and mainTopic are blank")
        void resolveTopic_throwsWhenBothTopicsAreBlank() {
            props.setMainTopic("  ");
            RequestPayload payload = buildPayload("  ", "k4", "data");

            assertThatThrownBy(() -> service.publishSync(payload))
                    .isInstanceOf(KafkaPublishException.class)
                    .hasMessageContaining("No topic specified");
        }
    }


    private RequestPayload buildPayload(String topic, String key, String payload) {
        return RequestPayload.builder()
                .topic(topic)
                .key(key)
                .payload(payload)
                .build();
    }

    @SuppressWarnings("unchecked")
    private CompletableFuture<SendResult<String, Object>> completedFuture(
            String topic, int partition, long offset) {

        RecordMetadata metadata = new RecordMetadata(
                new TopicPartition(topic, partition), offset, 0, 0L, 0, 0);
        ProducerRecord<String, Object> record = new ProducerRecord<>(topic, "key", new Object());
        SendResult<String, Object> sendResult = new SendResult<>(record, metadata);
        return CompletableFuture.completedFuture(sendResult);
    }
}

