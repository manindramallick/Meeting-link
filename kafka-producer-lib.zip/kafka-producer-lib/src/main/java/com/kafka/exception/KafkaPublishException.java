package com.kafka.exception;

import lombok.Getter;

/**
 * Thrown when a message cannot be published to Kafka.
 * Wraps the original cause so callers can inspect the root error.
 */
@Getter
public class KafkaPublishException extends RuntimeException {


    private final String topic;

    /**
     * Constructs a new KafkaPublishException with the specified topic and message.
     *
     * @param topic   the Kafka topic to which the publish attempt was made
     * @param message the detail message explaining the reason for the failure
     */
    public KafkaPublishException(String topic, String message) {
        super(message);
        this.topic = topic;
    }

    /**
     * Constructs a new KafkaPublishException with the specified topic, message, and cause.
     *
     * @param topic   the Kafka topic to which the publish attempt was made
     * @param message the detail message explaining the reason for the failure
     * @param cause   the underlying cause of the failure (e.g., a Kafka exception)
     */
    public KafkaPublishException(String topic, String message, Throwable cause) {
        super(message, cause);
        this.topic = topic;
    }

}

