package com.kafka.properties;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import java.util.HashMap;
import java.util.Map;


@Data
@ConfigurationProperties(prefix = "kafka.producer")
@Setter
@Getter

public class KafkaProducerProperties {

    private String bootstrapServers;
    private String apiKey;
    private String apiSecret;
    private String mainTopic;
    private int retries = 3;
    private String acks = "all";
    private Map<String, String> additionalProperties = new HashMap<>();
}

